
MODULE(i18n)
MODULE(syscalls)
MODULE(regexp)
MODULE(readline)
